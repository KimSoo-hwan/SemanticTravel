﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExitYN : MonoBehaviour
{
   public void OnClickExit()
    {
        Application.Quit();
        Debug.Log("YAYAYAYAYAYAYAYAYAYAYA");
    }
}
